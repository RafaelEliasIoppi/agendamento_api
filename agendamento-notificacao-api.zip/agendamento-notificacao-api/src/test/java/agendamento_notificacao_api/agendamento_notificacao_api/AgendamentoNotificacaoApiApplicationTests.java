package agendamento_notificacao_api.agendamento_notificacao_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgendamentoNotificacaoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
