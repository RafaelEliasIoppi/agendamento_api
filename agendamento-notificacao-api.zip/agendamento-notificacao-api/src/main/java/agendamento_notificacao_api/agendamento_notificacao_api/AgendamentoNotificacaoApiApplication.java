package agendamento_notificacao_api.agendamento_notificacao_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendamentoNotificacaoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgendamentoNotificacaoApiApplication.class, args);
	}

}
